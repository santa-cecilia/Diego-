/*
  # Schema inicial para o sistema de planejamento de aulas

  1. New Tables
    - `usuarios`
      - `id` (uuid, primary key)
      - `nome` (text)
      - `email` (text, unique)
      - `senha` (text)
      - `created_at` (timestamp)
    - `alunos`
      - `id` (uuid, primary key)
      - `usuario_id` (uuid, foreign key)
      - `nome` (text)
      - `nascimento` (date)
      - `idade` (integer)
      - `pais` (text)
      - `cidade` (text)
      - `servico` (text)
      - `dia_semana` (text)
      - `horario` (time)
      - `created_at` (timestamp)
    - `servicos`
      - `id` (uuid, primary key)
      - `usuario_id` (uuid, foreign key)
      - `instrumento` (text)
      - `tempo` (text)
      - `valor` (decimal)
      - `created_at` (timestamp)
    - `pagamentos`
      - `id` (uuid, primary key)
      - `usuario_id` (uuid, foreign key)
      - `nome_aluno` (text)
      - `month` (text)
      - `discount_percent` (decimal, default 0)
      - `paid` (boolean, default false)
      - `payment_date` (date)
      - `note` (text)
      - `created_at` (timestamp)
    - `financeiros`
      - `id` (uuid, primary key)
      - `usuario_id` (uuid, foreign key)
      - `tipo` (text)
      - `valor` (decimal)
      - `descricao` (text)
      - `data` (date)
      - `mes` (text)
      - `created_at` (timestamp)
    - `anotacoes`
      - `id` (uuid, primary key)
      - `usuario_id` (uuid, foreign key)
      - `aluno_nome` (text)
      - `texto` (text)
      - `data` (date)
      - `created_at` (timestamp)
    - `agenda_mensal`
      - `id` (uuid, primary key)
      - `usuario_id` (uuid, foreign key)
      - `data_evento` (date)
      - `slot` (integer)
      - `hora` (time)
      - `assunto` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access only their own data
*/

-- Criar tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  email text UNIQUE NOT NULL,
  senha text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de alunos
CREATE TABLE IF NOT EXISTS alunos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id uuid REFERENCES usuarios(id) ON DELETE CASCADE,
  nome text NOT NULL,
  nascimento date,
  idade integer,
  pais text,
  cidade text,
  servico text,
  dia_semana text,
  horario time,
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de serviços
CREATE TABLE IF NOT EXISTS servicos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id uuid REFERENCES usuarios(id) ON DELETE CASCADE,
  instrumento text NOT NULL,
  tempo text NOT NULL,
  valor decimal NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de pagamentos
CREATE TABLE IF NOT EXISTS pagamentos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id uuid REFERENCES usuarios(id) ON DELETE CASCADE,
  nome_aluno text NOT NULL,
  month text NOT NULL,
  discount_percent decimal DEFAULT 0,
  paid boolean DEFAULT false,
  payment_date date,
  note text,
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de financeiros
CREATE TABLE IF NOT EXISTS financeiros (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id uuid REFERENCES usuarios(id) ON DELETE CASCADE,
  tipo text NOT NULL,
  valor decimal NOT NULL,
  descricao text,
  data date NOT NULL,
  mes text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de anotações
CREATE TABLE IF NOT EXISTS anotacoes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id uuid REFERENCES usuarios(id) ON DELETE CASCADE,
  aluno_nome text NOT NULL,
  texto text NOT NULL,
  data date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de agenda mensal
CREATE TABLE IF NOT EXISTS agenda_mensal (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id uuid REFERENCES usuarios(id) ON DELETE CASCADE,
  data_evento date NOT NULL,
  slot integer NOT NULL,
  hora time,
  assunto text,
  created_at timestamptz DEFAULT now()
);

-- Habilitar RLS em todas as tabelas
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE alunos ENABLE ROW LEVEL SECURITY;
ALTER TABLE servicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pagamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE financeiros ENABLE ROW LEVEL SECURITY;
ALTER TABLE anotacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE agenda_mensal ENABLE ROW LEVEL SECURITY;

-- Políticas para usuários (podem acessar apenas seus próprios dados)
CREATE POLICY "Usuários podem ver seus próprios dados"
  ON usuarios
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = id::text);

CREATE POLICY "Usuários podem atualizar seus próprios dados"
  ON usuarios
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = id::text);

-- Políticas para alunos
CREATE POLICY "Usuários podem ver seus próprios alunos"
  ON alunos
  FOR ALL
  TO authenticated
  USING (usuario_id::text = auth.uid()::text);

-- Políticas para serviços
CREATE POLICY "Usuários podem gerenciar seus próprios serviços"
  ON servicos
  FOR ALL
  TO authenticated
  USING (usuario_id::text = auth.uid()::text);

-- Políticas para pagamentos
CREATE POLICY "Usuários podem gerenciar seus próprios pagamentos"
  ON pagamentos
  FOR ALL
  TO authenticated
  USING (usuario_id::text = auth.uid()::text);

-- Políticas para financeiros
CREATE POLICY "Usuários podem gerenciar seus próprios financeiros"
  ON financeiros
  FOR ALL
  TO authenticated
  USING (usuario_id::text = auth.uid()::text);

-- Políticas para anotações
CREATE POLICY "Usuários podem gerenciar suas próprias anotações"
  ON anotacoes
  FOR ALL
  TO authenticated
  USING (usuario_id::text = auth.uid()::text);

-- Políticas para agenda mensal
CREATE POLICY "Usuários podem gerenciar sua própria agenda"
  ON agenda_mensal
  FOR ALL
  TO authenticated
  USING (usuario_id::text = auth.uid()::text);